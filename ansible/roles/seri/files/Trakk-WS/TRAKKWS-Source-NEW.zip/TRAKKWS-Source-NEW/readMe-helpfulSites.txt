http://crunchify.com/how-to-build-restful-service-with-java-using-jax-rs-and-jersey/

http://tutorial-academy.com/restful-webservice-jersey-maven/

Also, don't forget to move web.xml into WEB-INF/  Not sure why this is not done by default in the
Maven build process

postService
http://crunchify.com/create-very-simple-jersey-rest-service-and-send-json-data-from-java-client/


You need to set your content-type to application/json. 
But -d sends the Content-Type application/x-www-form-urlencoded, which is not accepted on Spring's side.


curl -H "Content-Type: application/json" -X POST -d '{"username":"xyz","password":"xyz"}' http://localhost:3000/api/login
(-H is short for --header, -d for --data.)



curl -X POST 'http://localhost:8080/helloworld/rest/postService' \
-H "Content-Type: application/json" \
--data-urlencode 'To=+15558675309'  \
--data-urlencode 'From=+15017250604'  \
--data-urlencode 'Body=This is the ship that made the Kessel Run in fourteen parsecs?' 


curl -X POST 'http://localhost:8080/helloworld/rest/postService' \
-H "Content-Type: application/json" \
--data '{"To":"+15558675309","From":"15017250604","Body":"This is the ship that made the Kessel Run in fourteen parsecs?"}'



// This works perfectly as we are posting JSON
curl -X POST 'http://localhost:8080/helloworld/rest/postService' \
-H "Content-Type: application/json" \
-d '{"username":"Normie","password":"Wormie"}' 


// This works perfectly as we are posting JSON
curl -X POST 'http://localhost:8080/helloworld/rest/postService' \
-H "Content-Type: application/json"  \
-d '{"username":"xyz","password":"xyz"}' 