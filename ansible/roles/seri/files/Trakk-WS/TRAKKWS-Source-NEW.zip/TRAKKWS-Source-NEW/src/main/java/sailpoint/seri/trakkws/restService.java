package sailpoint.seri.trakkws;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


@Path("/")
public class restService {

    // private static Log log = LogFactory.getLog(WebServicesConnector.class);
    private static Log log = org.apache.commons.logging.LogFactory.getLog("SERI.TRAKK-WS");
    private String URL = "jdbc:mysql://ad-resource.seri.sailpointdemo.com/trakkws?allowPublicKeyRetrieval=true&useServerPrepStmts=true&tinyInt1isBit=true&useUnicode=true&characterEncoding=utf8";
    private String USER = "root";
    private String PASS = "sailpoint";

    
	@Path("/aggregate/{userId}")
	@GET
	@Produces("application/json")
	public Response getUsers(@PathParam("userId") String nativeIdentity) throws SQLException, ClassNotFoundException {
		// Load the MYSQL Driver.
		Class.forName("com.mysql.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection(URL, USER, PASS);
		Statement st = conn.createStatement();

		String SQL = "SELECT users.id,username,firstname,lastname,email,capability "
				+ "FROM users LEFT JOIN capabilities ON capabilities.id = users.id WHERE users.id = '" + nativeIdentity
				+ "'";

		ResultSet rs = st.executeQuery(SQL);

		String userId = null, username = null, firstname = null, lastname = null, email = null, capability = null;
		List capabilityList = new ArrayList();
		while (rs.next()) {
			userId = rs.getString("users.id");
			username = rs.getString("username");
			firstname = rs.getString("firstname");
			lastname = rs.getString("lastname");
			email = rs.getString("email");
			capability = rs.getString("capability");
			capabilityList.add(capability);
		}
		JSONObject responseObj = new JSONObject();
		responseObj.put("userId", userId);
		responseObj.put("username", username);
		responseObj.put("firstname", firstname);
		responseObj.put("lastname", lastname);
		responseObj.put("email", email);
		JSONArray myList = new JSONArray();
		myList.addAll(capabilityList);
		responseObj.put("capabilities", myList);

		if (conn != null)
			conn.close();
		if (st != null)
			st.close();

		return Response.status(200).entity(responseObj.toJSONString()).build();
	}

	@Path("/aggregate")
	@GET
	@Produces("application/json")
	public Response getUsers() throws SQLException, ClassNotFoundException {
		// Load the MYSQL Driver.
        Class.forName("com.mysql.jdbc.Driver");

        Connection conn = DriverManager.getConnection(URL, USER, PASS);
        ResultSet rs = null;
        Statement st = null;
        JSONObject accountsObject = new JSONObject();
        JSONArray list = new JSONArray();
        try {

            st = conn.createStatement();
            rs = st.executeQuery("select users.id,username,firstname,lastname,email,capability "
                    + "from users left outer join capabilities on users.id = capabilities.id order by users.id");

            String previousId = null;
            int users = 0;
            Map tmpUserMap = null;
            while (rs.next()) {
                
                // Read the userId from the DB
                String userId = rs.getString("users.id");
                
                // userId is different
                // case 1 : previous record is null => first record in the list. Store the values and continue
                // case 2 : previous record exists, we have to save it before reading the new record
                if (! userId.equals(previousId)) {
                    
                    if (tmpUserMap != null) {
                        JSONObject userObj = new JSONObject(tmpUserMap);
                        list.add(userObj);
                        users++;
                    }
                    
                    tmpUserMap = new HashMap();
                    tmpUserMap.put("userId", userId);
                    tmpUserMap.put("username", rs.getString("username"));
                    tmpUserMap.put("firstname", rs.getString("firstname"));
                    tmpUserMap.put("lastname", rs.getString("lastname"));
                    tmpUserMap.put("email", rs.getString("email"));
                    if (rs.getString("capability") != null && ! ("".equals(rs.getString("capability")))) {
                        List capabilities = new ArrayList();
                        capabilities.add(rs.getString("capability"));
                        // System.out.println(rs.getString("username") + ":" + rs.getString("capability"));
                        tmpUserMap.put("capabilities", capabilities);
                    }

                } else {
                    // userId is the same, just add the capability to the list
                    List capabilities = (List) tmpUserMap.get("capabilities");
                    capabilities.add(rs.getString("capability"));
                    tmpUserMap.put("capabilities", capabilities);
                    // System.out.println("Additional capability for " + tmpUserMap.get("username"));
                }
                previousId = userId;
                
            }
            
            // save the last object, because we exit the while loop without saving
            JSONObject userObj = new JSONObject(tmpUserMap);
            list.add(userObj);
            users++;

        } catch (SQLException ex) {
            System.out.println(ex);

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }

        accountsObject.put("trakkwsAccounts", list);
        return Response.status(200).entity(accountsObject.toJSONString()).build();		
	}

	@Path("/aggregateGroups")
	@GET
	@Produces("application/json")
	public Response getGroups() throws SQLException, ClassNotFoundException {
		// Load the MYSQL Driver.
		Class.forName("com.mysql.jdbc.Driver");

		Connection conn = DriverManager.getConnection(URL, USER, PASS);
		ResultSet rs = null;
		Statement st = null;
		JSONObject groupsObject = new JSONObject();
		JSONArray list = new JSONArray();
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT distinct capability,description  FROM capabilities");

			String capability = null, description = null;
			int numberOfCapabilties = 0;
			while (rs.next()) {
				numberOfCapabilties++;
				capability = rs.getString("capability");
				JSONObject groupObj = new JSONObject();
				groupObj.put("capability", rs.getString("capability"));
				groupObj.put("description", rs.getString("description"));
				list.add(groupObj);
			}
			// log.debug("Done with aggregating; " + numberOfCapabilties + " groups.");
		} catch (SQLException ex) {
			log.debug(ex);

		} finally {
			if (rs != null)
				rs.close();
			if (st != null)
				st.close();
			if (conn != null)
				conn.close();

		}

		groupsObject.put("trakkwsGroups", list);
		return Response.status(200).entity(groupsObject.toJSONString()).build();
	}

	@POST
	@Path("/createService")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces("application/json")
	public Response postTest(InputStream incomingData) throws ParseException, JsonGenerationException,
			JsonMappingException, IOException, SQLException, ClassNotFoundException {
		StringBuilder jsonString = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				jsonString.append(line);
			}
		} catch (Exception e) {
			log.debug("Error Parsing: - ");
		}
		log.debug("Create Service Data Received: " + jsonString.toString());
		System.out.println("Create Service Data Received: " + jsonString.toString());
		JSONParser jsonParser = new JSONParser();
		org.json.simple.JSONObject postObject = (JSONObject) jsonParser.parse(jsonString.toString());
		System.out.println("Return Object: " + postObject.toJSONString());
		// For some reason I am having issue with userId.  Testing with username to ensure it works
		String nativeId = (String) postObject.get("userId");
		
		Class.forName("com.mysql.jdbc.Driver");


		// Note, capabilities are not sent down (as a list) into this service
		// WebServiceConnector saves the add and remove list and then 
		// 'posts' to the add entitlement / remove entitlement web services.
		// I guess that is how simple request/response systems work :(

		// No test for null, no try/catch. This is shit code for testing
		Connection conn = DriverManager.getConnection(URL, USER, PASS);
		PreparedStatement statement = conn
				.prepareStatement("INSERT INTO users (id,username,firstname,lastname,email) VALUES(?,?,?,?,?)");	                                               
		statement.setString(1, nativeId);
		statement.setString(2, (String) postObject.get("username"));
		statement.setString(3, (String) postObject.get("firstname"));
		statement.setString(4, (String) postObject.get("lastname"));
		statement.setString(5, (String) postObject.get("email"));
		statement.executeUpdate();
		statement.close();
		conn.close();
		
		log.debug("Return Object: " + postObject.toJSONString());

		// At the end of the day, the response has to include the nativeIdentity
		// userId in this case. This allows IIQ to verify provisioning via a
		// getObject call
		// In this case, I just regurgitate the input since it contains the
		// userId
		return Response.status(200).entity(postObject.toJSONString()).build();
	}

	@POST
	@Path("/addEntitlementService")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces("application/json")
	public Response addEntitlement(InputStream incomingData) throws ParseException, JsonGenerationException,
			JsonMappingException, IOException, SQLException, ClassNotFoundException {
		// WebServicesConnector code sends capabilities in one at a time.
		// AFAIK, we get in the payload the entitlement (in this case
		// capabilities) and nativeIdeneity
		StringBuilder jsonString = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				jsonString.append(line);
			}
		} catch (Exception e) {
			log.debug("Error Parsing: - ");
		}
		System.out.println("addEntitlementService Data Received: " + jsonString.toString());
		log.debug("addEntitlementService Data Received: " + jsonString.toString());

		JSONParser jsonParser = new JSONParser();
		org.json.simple.JSONObject postObject = (JSONObject) jsonParser.parse(jsonString.toString());
		String nativeIdentity = (String) postObject.get("userId");
		String capability = (String) postObject.get("capabilities");
		System.out.println("WTF: " + nativeIdentity + "::" + capability);
		// Load the MYSQL Driver.
		Class.forName("com.mysql.jdbc.Driver");

		Connection connection = DriverManager.getConnection(URL, USER, PASS);
		PreparedStatement statement = connection.prepareStatement("INSERT INTO capabilities (id,capability) VALUES(?,?)");

		try {
			statement.setString(1, nativeIdentity);
			statement.setString(2, capability);
			statement.executeUpdate();
		} catch (SQLException e) {
			log.debug("Exception is: " + e);
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null)
				connection.close();
		}

		// just return back what we got. I think the only thing that matters is
		// we return nativeIdeneity (userId in this case)
		return Response.status(200).entity(postObject.toJSONString()).build();
	}

	@POST
	@Path("/removeEntitlementService")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces("application/json")
	public Response removeEntitlement(InputStream incomingData) throws ParseException, JsonGenerationException,
			JsonMappingException, IOException, SQLException, ClassNotFoundException {
		// WebServicesConnector code sends capabilities in one at a time.
		// AFAIK, we get in the payload the entitlement (in this case
		// capabilities) and nativeIdeneity
		StringBuilder jsonString = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				jsonString.append(line);
			}
		} catch (Exception e) {
			log.debug("Error Parsing: - ");
		}
		log.debug("removeEntitlementService Data Received: " + jsonString.toString());

		JSONParser jsonParser = new JSONParser();
		org.json.simple.JSONObject postObject = (JSONObject) jsonParser.parse(jsonString.toString());
		String nativeIdentity = (String) postObject.get("userId");
		String capability = (String) postObject.get("capabilities");

		// Load the MYSQL Driver.
		Class.forName("com.mysql.jdbc.Driver");

		Connection connection = DriverManager.getConnection(URL, USER, PASS);
		PreparedStatement statement = connection
				.prepareStatement("DELETE FROM capabilities WHERE id = ? and capability = ?");
		try {
			statement.setString(1, nativeIdentity);
			statement.setString(2, capability);
			statement.executeUpdate();
		} catch (SQLException e) {
			log.debug("Exception is: " + e);
		} finally {
			if (statement != null)
				statement.close();
			if (connection != null)
				connection.close();
		}
		// just return back what we got. I think the only thing that matters is
		// we return nativeIdeneity (userId in this case)
		return Response.status(200).entity(postObject.toJSONString()).build();
	}

	@DELETE
	@Path("/remove/{userId}")
	@Produces("application/json")
	public Response remove(@PathParam("userId") String nativeIdentity) throws SQLException, ClassNotFoundException {
		// Load the MYSQL Driver.
		Class.forName("com.mysql.jdbc.Driver");

		Connection connection = DriverManager.getConnection(URL, USER, PASS);
		PreparedStatement statement = connection.prepareStatement("DELETE FROM users WHERE users.id = ?");
		PreparedStatement statement2 = connection
				.prepareStatement("DELETE FROM capabilities WHERE capabilities.id = ?");
		try {
			statement.setString(1, nativeIdentity);
			statement.executeUpdate();
			statement2.setString(1, nativeIdentity);
			statement2.executeUpdate();
		} catch (SQLException e) {
			log.debug("Exception is: " + e);
		} finally {
			if (statement != null)
				statement.close();
			if (statement2 != null)
				statement2.close();
			if (connection != null) {
				connection.close();
			}
		}
		// return HTTP response 200 in case of success.
		return Response.status(200).build();
	}

	@Path("/test")
	@GET
	@Produces("text/html")
	public Response getStartingPage() {
		String output = "<h1>Hello there! Testing success!<h1>" + "<p>Simple RESTful Get Service is running ... <br>Ping @ "
				+ new Date().toString() + "</p<br>";
		return Response.status(200).entity(output).build();
	}


}
